
#### real data analysis ####

#### with estimated sigmae ####
#### with informative sources detection ####
set.seed(2025)
est_sigmae <- 0.20
AI <- c(1,2,6)

library("MASS")

setwd("/Users/jcwu/Documents/！paper/TL_interval-censored/real data")
all_p = 22189

TT <- 1
model0_par <- matrix(rep(0,TT*all_p),ncol=all_p)
model1_par <- matrix(rep(0,TT*all_p),ncol=all_p)    # TL: step 1
model2_par <- matrix(rep(0,TT*all_p),ncol=all_p)    # TL: step 2 

# compare to other methods
model3_par <- matrix(rep(0,TT*all_p),ncol=all_p)
model4_par <- matrix(rep(0,TT*all_p),ncol=all_p)
model5_par <- matrix(rep(0,TT*all_p),ncol=all_p)
model6_par <- matrix(rep(0,TT*all_p),ncol=all_p)

for(t in 1:TT){
  
  #### prepare the data ####
  load("little_real_data.RData")
  
  p0 <- 500
  for(i in 1:n0){
    Y0[i,2] <- ifelse(Y0[i,2]==100, Inf, Y0[i,2])
  }
  for(k in 1:K){
    for(i in 1:dim(Y[[k]])[1]){
      Y[[k]][i,2] <- ifelse(Y[[k]][i,2]==100, Inf, Y[[k]][i,2])
    }
  }
  
  # standardize all covariates
  
  # Xstar0 <- scale(log2(Xstar0))
  # for(k in 1:K){
  #   Xstar[[k]] <- scale(log2(Xstar[[k]]))
  # }
  
  # id0 <- sample(n0,replace=TRUE)
  # Y0 <- Y0[id0,]
  # Xstar0 <- Xstar0[id0,]
  Xstar0 <- scale(log2(Xstar0))

  id <- NULL
  for(k in 1:K){
    id[[k]] <- sample(n[k],replace=TRUE)
    Y[[k]] <- Y[[k]][id[[k]],]
    Xstar[[k]] <- Xstar[[k]][id[[k]],]
    Xstar[[k]] <- scale(log2(Xstar[[k]]))
  }
  # for(k in 1:K){
  #   Xstar[[k]] <- scale(log2(Xstar[[k]]))
  # }
  
  #### start to fit models ####
  #### fit on only target data ####
  model0 <- 
    SIMEXBoost(Y0, Xstar0, B=100, zeta=c(0, 0.25, 0.5, 0.75, 1),
               type="AFT-normal",Iter=50, sigmae=diag(est_sigmae,p0))
  
  #### combine informative source data ####
  Y_raw <- NULL
  Xstar_raw <- NULL
  for(k in AI){ 
    Y_raw <- rbind(Y_raw, Y[[k]])
    Xstar_raw <- rbind(Xstar_raw, Xstar[[k]])
  }
  
  Y_all <- rbind(Y0, Y_raw)
  Xstar_all <- rbind(Xstar0, Xstar_raw)
  
  
  #### Step 1 AND choose the variables ####
  model1 <- SIMEXBoost(Y_all, Xstar_all, B=100, zeta=c(0, 0.1, 0.25, 0.5, 0.6 ,0.75, 1),
                       type="AFT-normal", Iter=50, sigmae=diag(est_sigmae,p0))
  
  #### Step 2 ####
  covariates <- which(model1$BetaHatCorrect!=0)
  new_p <- length(covariates)
  Xstar0_step2 <- Xstar0[,covariates]
  beta_step1 <- model1$BetaHatCorrect[covariates]
  
  model2 <- SIMEXBoost2(Y0, Xstar0_step2, B=100, zeta=c(0, 0.25, 0.5, 0.75, 1),
                        type="AFT-normal",Iter=50,sigmae=diag(est_sigmae,new_p),betazero=beta_step1)
  model2_all <- rep(0,p0)
  model2_all[covariates] <- model2$BetaHatCorrect
  
  #### Naive Step 1 ####
  model3 <- SIMEXBoost3(Y_all, Xstar_all, B=100, zeta=c(0, 0),
                        type="AFT-normal",Iter=50,sigmae=diag(est_sigmae,p0))
  
  #### Naive Step 2 ####
  covariates <- which(model3$BetaHatCorrect!=0)
  new_p <- length(covariates)
  Xstar0_step2 <- Xstar0[,covariates]
  beta_step3 <- model3$BetaHatCorrect[covariates]
  
  model4 <- SIMEXBoost4(Y0, Xstar0_step2, B=100, zeta=c(0, 0),
                        type="AFT-normal",Iter=50,sigmae=diag(est_sigmae,new_p),betazero=beta_step3)
  model4_all <- rep(0,p0)
  model4_all[covariates] <- model4$BetaHatCorrect
  
  
  #### Naive target only ####
  model5 <- 
    SIMEXBoost3(Y0, Xstar0, B=100, zeta=c(0, 0),
                type="AFT-normal",Iter=50, sigmae=diag(est_sigmae,p0))
  
  
  model0_par[t, ind_screen] <- model0$BetaHatCorrect
  model1_par[t, ind_screen] <- model1$BetaHatCorrect
  model2_par[t, ind_screen] <- model2_all
  
  model3_par[t, ind_screen] <- model3$BetaHatCorrect
  model4_par[t, ind_screen] <- model4_all
  
  model5_par[t, ind_screen] <- model5$BetaHatCorrect
}

model0_par
model1_par
model2_par
model3_par
model4_par
model5_par

which(model0_par!=0)
which(model1_par!=0)
which(model2_par!=0)
which(model3_par!=0)
which(model4_par!=0)
which(model5_par!=0)

model0_par[,which(colMeans(model0_par)!=0)]
model1_par[,which(colMeans(model1_par)!=0)]
model2_par[,which(colMeans(model2_par)!=0)]
model3_par[,which(colMeans(model3_par)!=0)]
model4_par[,which(colMeans(model4_par)!=0)]
model5_par[,which(colMeans(model5_par)!=0)]

which(abs(colMeans(model0_par)) > 0.03)
colMeans(model0_par)
colMeans(model1_par)
colMeans(model2_par)
colMeans(model3_par)
colMeans(model4_par)
colMeans(model5_par)


save.image(file="real_data_analysis_with estimated sigmae020.RData")
