#### IBS_func: compute the IBS (integrated Brier Score) ####

IBS_func <- function(betahat, Y0_V, Xstar0_V, sigma = 1){
  
  beta_hat <- matrix(betahat,ncol=1)
  
  # 1. initial setting
  u_max <- max(Y0_V[is.finite(Y0_V)])
  M <- 300
  t_points <- seq(0, u_max, length.out = M)
  dt <- t_points[2] - t_points[1]            # assume same length
  
  
  # linear predictor
  LP <- as.vector(Xstar0_V %*% beta_hat) # parameter of meanlog
  N <- length(LP)
  
  
  # 2. compute S(t|X)
  # use outer to do vectorization (avoid double loop)
  # nrow = no. of subjects; ncol = no. of t_points
  S_hat_matrix <- t(apply(matrix(LP,ncol=1), 1, function(mu){
    1 - plnorm(
      q = t_points, 
      meanlog = mu, 
      sdlog = sigma
    )
  }))
  
  # 3. compute the survival function of each subject 
  L_vec <- Y0_V[, 1]
  R_vec <- Y0_V[, 2]
  
  S_L_vec <- 1 - plnorm(L_vec, meanlog = LP, sdlog = sigma)
  
  #  R_i = Inf: (S(Inf) = 0)
  S_R_vec <- numeric(N)
  finite_R_idx <- is.finite(R_vec)
  S_R_vec[finite_R_idx] <- 1 - plnorm(R_vec[finite_R_idx], meanlog = LP[finite_R_idx], sdlog = sigma)
  S_R_vec[!finite_R_idx] <- 0
  
  # 4. compute I_hat_matrix (N x M)
  I_hat_matrix <- matrix(NA, nrow = N, ncol = M)
  
  # use matrix to deal with all time points at the same time
  # build t_matrix: repeat t_points in each row
  t_matrix <- matrix(rep(t_points, each = N), nrow = N, ncol = M)
  
  # Cond 1: Event didn't happen yet (L_i >= t) -> I = 1
  cond1 <- (L_vec >= t_matrix)
  I_hat_matrix[cond1] <- 1
  
  # Cond 2: Event happened (R_i < t) -> I = 0
  cond2 <- (R_vec < t_matrix)
  I_hat_matrix[cond2] <- 0
  
  # Cond 3: Interval / Right Censored (L_i < t <= R_i)
  # warning: denominator may be 0 !!
  cond3 <- (!cond1 & !cond2)
  if (any(cond3)) {
    # expand  S_L and S_R into matrices
    S_L_mat <- matrix(rep(S_L_vec, times = M), nrow = N, ncol = M)
    S_R_mat <- matrix(rep(S_R_vec, times = M), nrow = N, ncol = M)
    
    numerator <- S_hat_matrix - S_R_mat
    denominator <- S_L_mat - S_R_mat
    
    # avoid extremely small denominator
    denominator[abs(denominator) < 1e-8] <- 1e-8 
    
    imputed_vals <- numerator / denominator
    
    # only put the place where condition 3 is TURE 
    I_hat_matrix[cond3] <- imputed_vals[cond3]
  }
  
  # 5. compute the IBS
  Squared_Error <- (I_hat_matrix - S_hat_matrix)^2
  
  # integral for each subject -> sum over columns * dt
  Integral_per_subject <- rowSums(Squared_Error) * dt
  
  # 6. take average
  IBS_value <- sum(Integral_per_subject) / (u_max * N)
  
  return(IBS_value)
  
}

#### LL_func ####
LL_func <- function(Y0_V, Xstar0_V, beta_hat, sigma = 1, sigma_e_matrix){
  
  extra_variance <- t(beta_hat) %*% sigma_e_matrix %*% beta_hat
  sigma_new <- sqrt(sigma^2 + as.numeric(extra_variance))
  
  # 1. 計算線性預測值 (Vectorized)
  mu <- Xstar0_V %*% matrix(beta_hat, ncol = 1)
  
  # 2. 取得上下界並標準化 (Standardize by sigma)
  # 假設模型: log(Y) = X*beta + sigma*error
  z_low <- (log(Y0_V[,1]) - mu) / sigma_new
  z_upp <- (log(Y0_V[,2]) - mu) / sigma_new
  
  # 3. 判斷受限類型 (Exact vs Interval)
  # 建議加入 tolerance 避免浮點數誤差，例如 abs(y2-y1) < 1e-8
  delta <- ifelse(Y0_V[,1] == Y0_V[,2], 1, 0)
  
  # 初始化 Log-Likelihood 向量
  ll_vec <- numeric(length(delta))
  
  # --- Case A: Exact Observations (delta == 1) ---
  # PDF contribution: (1/sigma) * phi(z)
  # Log-scale: log(dnorm(z)) - log(sigma)
  # 注意: 如果是對 log(Y) 建模，這就是針對 log(Y) 的密度。
  # 如果原變數是 Y，嚴格來說還要減去 log(Y) (Jacobian)，但這不影響 beta 的最佳化，可忽略。
  if(any(delta == 1)){
    idx <- which(delta == 1)
    ll_vec[idx] <- dnorm(z_low[idx], log = TRUE) - log(sigma_new)
  }
  
  # --- Case B: Interval Censored (delta == 0) ---
  # Probability contribution: Phi(z_upp) - Phi(z_low)
  if(any(delta == 0)){
    idx <- which(delta == 0)
    prob_diff <- pnorm(z_upp[idx]) - pnorm(z_low[idx])
    
    # 數值穩定性處理：避免 log(0)
    # 使用 pmax 確保機率至少有 Machine Epsilon，防止 -Inf
    ll_vec[idx] <- log(pmax(prob_diff, .Machine$double.eps))
  }
  
  # 4. 回傳總和
  return(sum(ll_vec))
}

#### Informative sources detection ####

est_sigmae <- 0.20
# library("SIMEXBoost")
library("MASS")
starting_time <- Sys.time()

setwd("/Users/jcwu/Documents/！paper/TL_interval-censored/real data")
load("little_real_data.RData")

Xstar0 <- Xstar0[, ind_screen]
for(k in 1:K){
  Xstar[[k]] <- Xstar[[k]][, ind_screen]
}

K <- 8
p0 <- 500

#### Separate X0 into 4 approximately equal size ####
R <- 4
ind <- NULL
for(r in 1:R){
  if(r==R){
    ind[[r]] <- ((r-1)*round(n0/R)+1):n0
  }else{
    ind[[r]] <- ((r-1)*round(n0/R)+1):(r*round(n0/R))
  }
}

#### store the results ####
LL <- matrix(rep(NA,(K*R)),ncol=R)
IBS_value <- matrix(rep(NA,(K*R)),ncol=R)
model1_store <- array(NA, c(K,R,p0))
model2_store <- array(NA, c(K,R,p0))


for(i in 1:n0){
  Y0[i,2] <- ifelse(Y0[i,2]==100, Inf, Y0[i,2])
}
for(k in 1:K){
  for(i in 1:dim(Y[[k]])[1]){
    Y[[k]][i,2] <- ifelse(Y[[k]][i,2]==100, Inf, Y[[k]][i,2])
  }
}


#### informative source selection ####

for(k in 1:K){
  
  for(r in 1:R){
    
    Y0_T <- Y0[-ind[[r]],]
    Y0_V <- Y0[ ind[[r]],]
    Xstar0_T <- scale(log2(Xstar0))[-ind[[r]],]
    Xstar0_V <- scale(log2(Xstar0))[ ind[[r]],]
    
    Y_raw <- NULL
    Xstar_raw <- NULL
    
    Y_raw <- Y[[k]]
    Xstar_raw <- scale(log2(Xstar[[k]]))
    
    Y_all <- rbind(Y0_T, Y_raw)
    Xstar_all <- rbind(Xstar0_T, Xstar_raw)
    
    
    #### Step 1 AND choose the variables ####
    model1 <- SIMEXBoost(Y_all,Xstar_all,B=100,zeta=c(0, 0.25, 0.50, 0.75, 1),
                         type="AFT-normal",Iter=80,sigmae=diag(est_sigmae,p0))
    model1$BetaHatCorrect
    model1_store[k,r,] <- model1$BetaHatCorrect
    
    #### Step 2 ####
    covariates <- which(model1$BetaHatCorrect!=0)
    if(length(covariates)==0){
      model2_all <- rep(0,p0)
      model2_all[covariates] <- model1$BetaHatCorrect
      model2_store[k,r,] <- model2_all
    }else if(length(covariates)==1){
      model1$BetaHatCorrect[500] <- 0.0001
      covariates <- which(model1$BetaHatCorrect!=0)
      new_p <- length(covariates)
      Xstar0_step2 <- Xstar0_T[,covariates]
      beta_step1 <- model1$BetaHatCorrect[covariates]
      
      model2 <- SIMEXBoost2(Y0_T,Xstar0_step2,B=100,zeta=c(0, 0.25, 0.50, 0.75, 1),
                            type="AFT-normal",Iter=80,sigmae=diag(est_sigmae,new_p),betazero=beta_step1)
      model2_all <- rep(0,p0)
      model2_all[covariates] <- model2$BetaHatCorrect
      model2_store[k,r,] <- model2_all
    }else if(length(covariates)>=2){
      covariates <- which(model1$BetaHatCorrect!=0)
      new_p <- length(covariates)
      Xstar0_step2 <- Xstar0_T[,covariates]
      beta_step1 <- model1$BetaHatCorrect[covariates]
      
      model2 <- SIMEXBoost2(Y0_T,Xstar0_step2,B=100,zeta=c(0, 0.25, 0.50, 0.75, 1),
                            type="AFT-normal",Iter=80,sigmae=diag(est_sigmae,new_p),betazero=beta_step1)
      model2_all <- rep(0,p0)
      model2_all[covariates] <- model2$BetaHatCorrect
      model2_store[k,r,] <- model2_all
    }
    
    #### see if yhat is in the interval Y0_V ####
    #yhat <- exp(Xstar0_V %*% matrix(model2_all,ncol=1))
    LL[k, r] <- LL_func(Y0_V=Y0_V, Xstar0_V=Xstar0_V, beta_hat=model2_store[k,r,])
    
    IBS_value[k, r] <- IBS_func(betahat=model2_store[k,r,], Y0_V=Y0_V, Xstar0_V=Xstar0_V)
    
  }
  
}

LL_0 <- rep(NA, R)
IBS_value_0 <- rep(NA, R)
model0_store <- array(NA, c(R,p0))
for(r in 1:R){
  
  Y0_T <- Y0[-ind[[r]],]
  Y0_V <- Y0[ ind[[r]],]
  Xstar0_T <- Xstar0[-ind[[r]],]
  Xstar0_V <- Xstar0[ ind[[r]],]
  
  model1 <- SIMEXBoost(Y0_T,Xstar0_T,B=100,zeta=c(0, 0.25, 0.50, 0.75, 1),
                       type="AFT-normal",Iter=80,sigmae=diag(est_sigmae,p0))
  
  model2_all <- model1$BetaHatCorrect
  model0_store[r,] <- model2_all
  #### see if yhat is in the interval Y0_V ####
  #yhat <- exp(Xstar0_V %*% matrix(model2_all,ncol=1))
  LL_0[r] <- LL_func(Y0_V=Y0_V, Xstar0_V=Xstar0_V, beta_hat=model0_store[r,])
  
  IBS_value_0[r] <- IBS_func(betahat=model0_store[r,], Y0_V=Y0_V, Xstar0_V=Xstar0_V)
}


ending_time <- Sys.time()

ending_time - starting_time


(rowMeans(LL) - mean(LL_0))/sd(LL_0)

count <- rep(NA, K)
for(k in 1:K){
  count[k] <- sum((LL_0 - LL[k,]) <= 0)
}
which(count>=3)

# gain <- rep(NA, K)
# for(k in 1:K){
#   gain_0 <- (mean(LL[k,]) - mean(LL_0))/abs(mean(LL_0))
#   gain[k] <- print(gain_0)
# }


# setwd("/Users/jcwu/Documents/！paper/TL_interval-censored/simulation_store_RData")
# save.image(file="real_data_infor_detection_20251218_0011.RData")