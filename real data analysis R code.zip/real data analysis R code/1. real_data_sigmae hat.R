#### 先log2完再scale ####

#### 估計sigmae ####


#### real data: estimate sigma_e ####
#### IBS_func: compute the IBS (integrated Brier Score) ####

IBS_func <- function(betahat, Y0_V, Xstar0_V, sigma = 1){
  
  beta_hat <- matrix(betahat,ncol=1)
  
  # 1. initial setting
  u_max <- max(Y0_V[is.finite(Y0_V)])
  M <- 300
  t_points <- seq(0, u_max, length.out = M)
  dt <- t_points[2] - t_points[1]            # assume same length
  
  
  # linear predictor
  LP <- as.vector(Xstar0_V %*% beta_hat) # parameter of meanlog
  N <- length(LP)
  
  
  # 2. compute S(t|X)
  # use outer to do vectorization (avoid double loop)
  # nrow = no. of subjects; ncol = no. of t_points
  S_hat_matrix <- t(apply(matrix(LP,ncol=1), 1, function(mu){
    1 - plnorm(
      q = t_points, 
      meanlog = mu, 
      sdlog = sigma
    )
  }))
  
  # 3. compute the survival function of each subject 
  L_vec <- Y0_V[, 1]
  R_vec <- Y0_V[, 2]
  
  S_L_vec <- 1 - plnorm(L_vec, meanlog = LP, sdlog = sigma)
  
  #  R_i = Inf: (S(Inf) = 0)
  S_R_vec <- numeric(N)
  finite_R_idx <- is.finite(R_vec)
  S_R_vec[finite_R_idx] <- 1 - plnorm(R_vec[finite_R_idx], meanlog = LP[finite_R_idx], sdlog = sigma)
  S_R_vec[!finite_R_idx] <- 0
  
  # 4. compute I_hat_matrix (N x M)
  I_hat_matrix <- matrix(NA, nrow = N, ncol = M)
  
  # use matrix to deal with all time points at the same time
  # build t_matrix: repeat t_points in each row
  t_matrix <- matrix(rep(t_points, each = N), nrow = N, ncol = M)
  
  # Cond 1: Event didn't happen yet (L_i >= t) -> I = 1
  cond1 <- (L_vec >= t_matrix)
  I_hat_matrix[cond1] <- 1
  
  # Cond 2: Event happened (R_i < t) -> I = 0
  cond2 <- (R_vec < t_matrix)
  I_hat_matrix[cond2] <- 0
  
  # Cond 3: Interval / Right Censored (L_i < t <= R_i)
  # warning: denominator may be 0 !!
  cond3 <- (!cond1 & !cond2)
  if (any(cond3)) {
    # expand  S_L and S_R into matrices
    S_L_mat <- matrix(rep(S_L_vec, times = M), nrow = N, ncol = M)
    S_R_mat <- matrix(rep(S_R_vec, times = M), nrow = N, ncol = M)
    
    numerator <- S_hat_matrix - S_R_mat
    denominator <- S_L_mat - S_R_mat
    
    # avoid extremely small denominator
    denominator[abs(denominator) < 1e-8] <- 1e-8 
    
    imputed_vals <- numerator / denominator
    
    # only put the place where condition 3 is TURE 
    I_hat_matrix[cond3] <- imputed_vals[cond3]
  }
  
  # 5. compute the IBS
  Squared_Error <- (I_hat_matrix - S_hat_matrix)^2
  
  # integral for each subject -> sum over columns * dt
  Integral_per_subject <- rowSums(Squared_Error) * dt
  
  # 6. take average
  IBS_value <- sum(Integral_per_subject) / (u_max * N)
  
  return(IBS_value)
  
}
#### start to estimate  ####

library("MASS")
starting_time <- Sys.time()

setwd("/Users/jcwu/Documents/！paper/TL_interval-censored/real data")
load("little_real_data.RData")


#### estimate Sigma_e ####
cut_points <- seq(0.05, 1, by=0.05)
Nc <- length(cut_points)

# separate target data into R folds ####
R <- 4
ind <- NULL
for(r in 1:R){
  if(r==R){
    ind[[r]] <- ((r-1)*round(n0/R)+1):n0
  }else{
    ind[[r]] <- ((r-1)*round(n0/R)+1):(r*round(n0/R))
  }
}

#### store the results ####
LL <- matrix(rep(NA,(Nc*R)),ncol=R)
IBS_value <- matrix(rep(NA,(Nc*R)),ncol=R)
model1_store <- array(NA, c(Nc,R,p0))
model2_store <- array(NA, c(Nc,R,p0))

for(i in 1:117){
  Y0[i,2] <- ifelse(Y0[i,2]==100, Inf, Y0[i,2])
}
for(k in 1:K){
  for(i in 1:dim(Y[[k]])[1]){
    Y[[k]][i,2] <- ifelse(Y[[k]][i,2]==100, Inf, Y[[k]][i,2])
  }
}

#### estimate Sigma_e ####
for(cc in 1:length(cut_points)){
  
  for(r in 1:R){
    
    Y0_T <- Y0[-ind[[r]],]
    Y0_V <- Y0[ ind[[r]],]
    Xstar0_T <- scale(log2(Xstar0))[-ind[[r]],]
    Xstar0_V <- scale(log2(Xstar0))[ ind[[r]],]
    
    Y_raw <- NULL
    Xstar_raw <- NULL
    
    # Y_raw <- rbind(Y[[1]],Y[[2]],Y[[3]],Y[[4]],Y[[5]],
    #                Y[[6]],Y[[7]],Y[[8]])
    # Xstar_raw <- rbind(scale(Xstar[[1]]),scale(Xstar[[2]]),scale(Xstar[[3]]),
    #                    scale(Xstar[[4]]),scale(Xstar[[5]]),scale(Xstar[[6]]),
    #                    scale(Xstar[[7]]),scale(Xstar[[8]]))
    # 
    # Y_all <- rbind(Y0_T, Y_raw)
    # Xstar_all <- rbind(Xstar0_T, Xstar_raw)
    Y_all <- Y0_T
    Xstar_all <- Xstar0_T
    
    
    #### Step 1 AND choose the variables ####
    model1 <- SIMEXBoost(Y_all,Xstar_all,B=100,zeta=c(0, 0.25, 0.50, 0.75, 1),
                         type="AFT-normal",Iter=30,sigmae=diag(cut_points[cc],p0))
    model1$BetaHatCorrect
    model1_store[cc,r,] <- model1$BetaHatCorrect
    
    
    #### Step 2 ####
    covariates <- which(model1$BetaHatCorrect!=0)
    if(length(covariates)==0){
      model2_all <- rep(0,p0)
      model2_all[covariates] <- model1_store[cc,r,]
      model2_store[cc,r,] <- model2_all
    }else if(length(covariates)==1){
      model1$BetaHatCorrect[6] <- 0.0001
      covariates <- which(model1$BetaHatCorrect!=0)
      new_p <- length(covariates)
      Xstar0_step2 <- Xstar0_T[,covariates]
      beta_step1 <- model1$BetaHatCorrect[covariates]
      
      model2 <- SIMEXBoost2(Y0_T,Xstar0_step2,B=100,zeta=c(0, 0.25, 0.50, 0.75, 1),
                            type="AFT-normal",Iter=30,sigmae=diag(cut_points[cc],new_p),betazero=beta_step1)
      model2_all <- rep(0,p0)
      model2_all[covariates] <- model2$BetaHatCorrect
      model2_store[cc,r,] <- model2_all
    }else if(length(covariates)>=2){
      covariates <- which(model1$BetaHatCorrect!=0)
      new_p <- length(covariates)
      Xstar0_step2 <- Xstar0_T[,covariates]
      beta_step1 <- model1$BetaHatCorrect[covariates]
      
      model2 <- SIMEXBoost2(Y0_T,Xstar0_step2,B=100,zeta=c(0, 0.25, 0.50, 0.75, 1),
                            type="AFT-normal",Iter=30,sigmae=diag(cut_points[cc],new_p),betazero=beta_step1)
      model2_all <- rep(0,p0)
      model2_all[covariates] <- model2$BetaHatCorrect
      model2_store[cc,r,] <- model2_all
    }
    
    #### see if yhat is in the interval Y0_V ####
    #yhat <- exp(Xstar0_V %*% matrix(model1$BetaHatCorrect,ncol=1))
    LL[cc, r] <- LL_func(Y0_V=Y0_V, Xstar0_V=Xstar0_V, beta_hat=model2_store[cc,r,])
    
    IBS_value[cc, r] <- IBS_func(betahat=model2_store[cc,r,], Y0_V=Y0_V, Xstar0_V=Xstar0_V)
    
  }
  
}


# LL
# rowMeans(LL)
# cut_points[which(rowMeans(LL) == max(rowMeans(LL)))]

IBS_value
rowMeans(IBS_value)
cut_points[which(rowMeans(IBS_value) == min(rowMeans(IBS_value)))]

# 20251217: sigmae hat = 0.20

ending_time <- Sys.time()

ending_time - starting_time