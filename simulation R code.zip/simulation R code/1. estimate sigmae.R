#### IBS_func: compute the IBS (integrated Brier Score) ####

IBS_func <- function(betahat, Y0_V, Xstar0_V, sigma = 1){
  
  beta_hat <- matrix(betahat,ncol=1)
  
  # 1. initial setting
  u_max <- max(Y0_V[is.finite(Y0_V)])
  M <- 300
  t_points <- seq(0, u_max, length.out = M)
  dt <- t_points[2] - t_points[1]            # assume same length
  
  
  # linear predictor
  LP <- as.vector(Xstar0_V %*% beta_hat) # parameter of meanlog
  N <- length(LP)
  
  
  # 2. compute S(t|X)
  # use outer to do vectorization (avoid double loop)
  # nrow = no. of subjects; ncol = no. of t_points
  S_hat_matrix <- t(apply(matrix(LP,ncol=1), 1, function(mu){
    1 - plnorm(
      q = t_points, 
      meanlog = mu, 
      sdlog = sigma
    )
  }))
  
  # 3. compute the survival function of each subject 
  L_vec <- Y0_V[, 1]
  R_vec <- Y0_V[, 2]
  
  S_L_vec <- 1 - plnorm(L_vec, meanlog = LP, sdlog = sigma)
  
  #  R_i = Inf: (S(Inf) = 0)
  S_R_vec <- numeric(N)
  finite_R_idx <- is.finite(R_vec)
  S_R_vec[finite_R_idx] <- 1 - plnorm(R_vec[finite_R_idx], meanlog = LP[finite_R_idx], sdlog = sigma)
  S_R_vec[!finite_R_idx] <- 0
  
  # 4. compute I_hat_matrix (N x M)
  I_hat_matrix <- matrix(NA, nrow = N, ncol = M)
  
  # use matrix to deal with all time points at the same time
  # build t_matrix: repeat t_points in each row
  t_matrix <- matrix(rep(t_points, each = N), nrow = N, ncol = M)
  
  # Cond 1: Event didn't happen yet (L_i >= t) -> I = 1
  cond1 <- (L_vec >= t_matrix)
  I_hat_matrix[cond1] <- 1
  
  # Cond 2: Event happened (R_i < t) -> I = 0
  cond2 <- (R_vec < t_matrix)
  I_hat_matrix[cond2] <- 0
  
  # Cond 3: Interval / Right Censored (L_i < t <= R_i)
  # warning: denominator may be 0 !!
  cond3 <- (!cond1 & !cond2)
  if (any(cond3)) {
    # expand  S_L and S_R into matrices
    S_L_mat <- matrix(rep(S_L_vec, times = M), nrow = N, ncol = M)
    S_R_mat <- matrix(rep(S_R_vec, times = M), nrow = N, ncol = M)
    
    numerator <- S_hat_matrix - S_R_mat
    denominator <- S_L_mat - S_R_mat
    
    # avoid extremely small denominator
    denominator[abs(denominator) < 1e-8] <- 1e-8 
    
    imputed_vals <- numerator / denominator
    
    # only put the place where condition 3 is TURE 
    I_hat_matrix[cond3] <- imputed_vals[cond3]
  }
  
  # 5. compute the IBS
  Squared_Error <- (I_hat_matrix - S_hat_matrix)^2
  
  # integral for each subject -> sum over columns * dt
  Integral_per_subject <- rowSums(Squared_Error) * dt
  
  # 6. take average
  IBS_value <- sum(Integral_per_subject) / (u_max * N)
  
  return(IBS_value)
  
}

#### LL_func ####
LL_func <- function(Y0_V, Xstar0_V, beta_hat, sigma = 1){
  
  # 1. 計算線性預測值 (Vectorized)
  mu <- Xstar0_V %*% matrix(beta_hat, ncol = 1)
  
  # 2. 取得上下界並標準化 (Standardize by sigma)
  # 假設模型: log(Y) = X*beta + sigma*error
  z_low <- (log(Y0_V[,1]) - mu) / sigma
  z_upp <- (log(Y0_V[,2]) - mu) / sigma
  
  # 3. 判斷受限類型 (Exact vs Interval)
  # 建議加入 tolerance 避免浮點數誤差，例如 abs(y2-y1) < 1e-8
  delta <- ifelse(Y0_V[,1] == Y0_V[,2], 1, 0)
  
  # 初始化 Log-Likelihood 向量
  ll_vec <- numeric(length(delta))
  
  # --- Case A: Exact Observations (delta == 1) ---
  # PDF contribution: (1/sigma) * phi(z)
  # Log-scale: log(dnorm(z)) - log(sigma)
  # 注意: 如果是對 log(Y) 建模，這就是針對 log(Y) 的密度。
  # 如果原變數是 Y，嚴格來說還要減去 log(Y) (Jacobian)，但這不影響 beta 的最佳化，可忽略。
  if(any(delta == 1)){
    idx <- which(delta == 1)
    ll_vec[idx] <- dnorm(z_low[idx], log = TRUE) - log(sigma)
  }
  
  # --- Case B: Interval Censored (delta == 0) ---
  # Probability contribution: Phi(z_upp) - Phi(z_low)
  if(any(delta == 0)){
    idx <- which(delta == 0)
    prob_diff <- pnorm(z_upp[idx]) - pnorm(z_low[idx])
    
    # 數值穩定性處理：避免 log(0)
    # 使用 pmax 確保機率至少有 Machine Epsilon，防止 -Inf
    ll_vec[idx] <- log(pmax(prob_diff, .Machine$double.eps))
  }
  
  # 4. 回傳總和
  return(sum(ll_vec))
}




# use only the target data to estimate sigmae

#### estimate Sigma_e ####
cut_points <- seq(0.05, 1, by=0.05)
Nc <- length(cut_points)


library("MASS")
starting_time <- Sys.time()


#### set the target and the source data ####

p0 <- 100
n0 <- 100
n <- rep(50,10)#c(100,100,100,100,100,100,100,100,100,100)
K <- length(n)
#TT <- 5
beta_set <- c(1,1,1,rep(0,p0-3))
beta_set2 <- c(0,1,1,1,0,0,rep(0, p0-6))


X0 <- matrix(rnorm((p0)*n0),nrow=n0,ncol=p0,byrow=TRUE)
data0=ME_Data_new(X0,beta=beta_set,pr0=0.2,
                  type="AFT-normal",
                  sigmae=diag(0.25,p0))
Y0 <- data0$response
Xstar0 = data0$ME_covariate


X <- NULL
data <- NULL
Y <- NULL
Xstar <- NULL

for(k in 1:K){
  X[[k]] <- matrix(rnorm((p0)*n[k]),nrow=n[k],ncol=p0,byrow=TRUE)
}

AI <- 5 # number of informative sources
for(k in 1:K){
  
  if(k<=AI){
    data[[k]] <- ME_Data_new(X[[k]],beta=beta_set,pr0=0.2,
                             type="AFT-normal",
                             sigmae=diag(0.25,p0))
  }else{
    data[[k]] <- ME_Data_new(X[[k]],beta=beta_set2,pr0=0.2,
                             type="AFT-normal",
                             sigmae=diag(0.25,p0))
  }
  
  Y[[k]] <- data[[k]]$response
  Xstar[[k]] = data[[k]]$ME_covariate
  
}

#### only use the target data to estimate Sigma_e ####

#### Separate X0 into 4 approximately equal size ####
R <- 4
ind <- NULL
for(r in 1:R){
  if(r==R){
    ind[[r]] <- ((r-1)*round(n0/R)+1):n0
  }else{
    ind[[r]] <- ((r-1)*round(n0/R)+1):(r*round(n0/R))
  }
}

LL <- matrix(rep(NA,(Nc*R)),ncol=R)
IBS_value <- matrix(rep(NA,(Nc*R)),ncol=R)
model1_store <- array(NA, c(Nc,R,p0))
model2_store <- array(NA, c(Nc,R,p0))

#### estimate Sigma_e ####
for(cc in 1:length(cut_points)){
  
  for(r in 1:R){
    
    Y0_T <- Y0[-ind[[r]],]
    Y0_V <- Y0[ ind[[r]],]
    Xstar0_T <- Xstar0[-ind[[r]],]
    Xstar0_V <- Xstar0[ ind[[r]],]
    
    Y_raw <- NULL
    Xstar_raw <- NULL
    
    # Y_raw <- rbind(Y[[1]],Y[[2]],Y[[3]],Y[[4]],Y[[5]],
    #                Y[[6]],Y[[7]],Y[[8]],Y[[9]],Y[[10]])
    # Xstar_raw <- rbind(Xstar[[1]],Xstar[[2]],Xstar[[3]],
    #                    Xstar[[4]],Xstar[[5]],Xstar[[6]],
    #                    Xstar[[7]],Xstar[[8]],Xstar[[9]],
    #                    Xstar[[10]])
    # 
    # Y_all <- rbind(Y0_T, Y_raw)
    # Xstar_all <- rbind(Xstar0_T, Xstar_raw)
    Y_all <- Y0_T
    Xstar_all <- Xstar0_T
    
    #### Step 1 AND choose the variables ####
    model1 <- SIMEXBoost(Y_all,Xstar_all,B=100,zeta=c(0, 0.25, 0.50, 0.75, 1),
                         type="AFT-normal",Iter=20,sigmae=diag(cut_points[cc],p0))
    model1$BetaHatCorrect
    model1_store[cc,r,] <- model1$BetaHatCorrect
    
    
    #### Step 2 ####
    covariates <- which(model1$BetaHatCorrect!=0)
    if(length(covariates)==0){
      model2_all <- rep(0,p0)
      model2_all[covariates] <- model1$BetaHatCorrect
      model2_store[cc,r,] <- model2_all
    }else if(length(covariates)==1){
      model1$BetaHatCorrect[6] <- 0.0001
      covariates <- which(model1$BetaHatCorrect!=0)
      new_p <- length(covariates)
      Xstar0_step2 <- Xstar0_T[,covariates]
      beta_step1 <- model1$BetaHatCorrect[covariates]
      
      model2 <- SIMEXBoost2(Y0_T,Xstar0_step2,B=100,zeta=c(0, 0.25, 0.50, 0.75, 1),
                            type="AFT-normal",Iter=20,sigmae=diag(cut_points[cc],new_p),betazero=beta_step1)
      model2_all <- rep(0,p0)
      model2_all[covariates] <- model2$BetaHatCorrect
      model2_store[cc,r,] <- model2_all
    }else if(length(covariates)>=2){
      covariates <- which(model1$BetaHatCorrect!=0)
      new_p <- length(covariates)
      Xstar0_step2 <- Xstar0_T[,covariates]
      beta_step1 <- model1$BetaHatCorrect[covariates]
      
      model2 <- SIMEXBoost2(Y0_T,Xstar0_step2,B=100,zeta=c(0, 0.25, 0.50, 0.75, 1),
                            type="AFT-normal",Iter=20,sigmae=diag(cut_points[cc],new_p),betazero=beta_step1)
      model2_all <- rep(0,p0)
      model2_all[covariates] <- model2$BetaHatCorrect
      model2_store[cc,r,] <- model2_all
    }
    
    
    #### see if yhat is in the interval Y0_V ####
    #yhat <- exp(Xstar0_V %*% matrix(model1$BetaHatCorrect,ncol=1))
    LL[cc, r] <- LL_func(Y0_V=Y0_V, Xstar0_V=Xstar0_V, beta_hat=model2_all)
    
    IBS_value[cc, r] <- IBS_func(betahat=model2_all, Y0_V=Y0_V, Xstar0_V=Xstar0_V)
    
  }
  
}

LL
rowMeans(LL)
cut_points[which(rowMeans(LL) == max(rowMeans(LL)))]

IBS_value
rowMeans(IBS_value)
cut_points[which(rowMeans(IBS_value) == min(rowMeans(IBS_value)))]


ending_time <- Sys.time()

ending_time - starting_time


#setwd("/Users/jcwu/Documents/！paper/TL_interval-censored/simulation_store_RData")
#save.image(file="tmp_infor_20251212_25left.RData")
#save.image(file="tmp_20251215_sigmae25.RData")
