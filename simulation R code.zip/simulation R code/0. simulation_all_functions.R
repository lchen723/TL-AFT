#### All revised functions ####
#### ME_Data_new: interval censored (pr0: the ratio of exact event time obs.) ####
ME_Data_new <- function (X, beta, type = "normal", sigmae, pr0 = 0.5) 
{
  if (dim(X)[2] != dim(sigmae)[2]) 
    return("ERROR:sigmae should have the same dimension with Xstar")
  if (length(beta) != dim(X)[2]) 
    return("ERROR:length(beta) should equal to X de dimension")
  if (type != "normal" & type != "binary" & type != "poisson" & 
      type != "AFT-normal" & type != "AFT-loggamma") 
    return("ERROR:tpye set error")
  if (pr0 < 0 | pr0 > 1) 
    return("ERROR:pr0 should in (0,1)")
  p = dim(X)[2]
  n = dim(X)[1]
  xtbeta <- (t(X)) * beta
  Y = NULL
  if (type == "AFT-normal") {
    logT = NULL
    for (i in 1:n) {
      e <- rnorm(1)
      logt = sum(xtbeta[, i]) + e
      logT = cbind(logT, logt)
    }
    Y = exp(logT)
    Y1 = Y
    
    delta = rbinom(length(Y1), 1, pr0)
    interval = which(delta == 1)
    Y1real <- Y1[interval]
    Y1censor <- Y1[-interval]
    
    ### change here 
    # create a sequence for censored data
    u <- 0
    seq_points <- 0
    while(u <= max(Y)){
      u <- u + 0.1 + runif(1, 0, 1)
      seq_points <- c(seq_points, u)
    }
    
    # convert into censored data 
    YL <- Y
    YR <- Y
    Y1censor # time point
    indices <- findInterval(Y1censor, seq_points)
    lhs <- seq_points[indices]
    rhs <- seq_points[indices + 1]
    YL[-interval] <- seq_points[indices]
    YR[-interval] <- seq_points[indices + 1] 
    
    ### change here
    
    Y <- rbind(YL, YR)
    
  }
  Xstar <- X + mvrnorm(n = n, rep(0, p), sigmae)
  List = list(response = t(Y), ME_covariate = Xstar)
  return(List)
}
#### ME_Data_new_right: right censored (pr0: the ratio of exact event time obs.) ####
ME_Data_new_right <- function (X, beta, type = "normal", sigmae, pr0 = 0.5) 
{
  if (dim(X)[2] != dim(sigmae)[2]) 
    return("ERROR:sigmae should have the same dimension with Xstar")
  if (length(beta) != dim(X)[2]) 
    return("ERROR:length(beta) should equal to X de dimension")
  if (type != "normal" & type != "binary" & type != "poisson" & 
      type != "AFT-normal" & type != "AFT-loggamma") 
    return("ERROR:tpye set error")
  if (pr0 < 0 | pr0 > 1) 
    return("ERROR:pr0 should in (0,1)")
  p = dim(X)[2]
  n = dim(X)[1]
  xtbeta <- (t(X)) * beta
  Y = NULL
  if (type == "AFT-normal") {
    logT = NULL
    for (i in 1:n) {
      e <- rnorm(1)
      logt = sum(xtbeta[, i]) + e
      logT = cbind(logT, logt)
    }
    Y = exp(logT)
    T_true = t(Y)
    
    # find the max(C) in uniform for controlling pr0
    target_censoring_rate <- 1 - pr0 
    
    # define a target function (now ratio - target raio = 0)
    find_max_c <- function(max_C_param) {
      C_temp <- runif(n, min = 0, max = max_C_param) # generate a C (uniform distribution) 
      current_rate <- mean(T_true > C_temp)          # compute the ratio now
      return(current_rate - target_censoring_rate)   # return the difference the ratio
    }
    
    optimal_max_c <- uniroot(f = find_max_c, 
                             interval = c(min(T_true) * 0.1, max(T_true) * 5) 
    )$root
    
    C_time <- runif(n, min = 0, max = optimal_max_c)     # generate final C
    Time <- pmin(T_true, C_time)
    status <- as.numeric(T_true <= C_time)               # 1=Event, 0=Censored
    final_censoring_rate <- 1 - mean(status)             # check final pr0
    Time2 <- ifelse(status==1, Time, Inf)
    Y <- t(cbind(Time,Time2))
  }
  Xstar <- X + mvrnorm(n = n, rep(0, p), sigmae)
  List = list(response = t(Y), ME_covariate = Xstar)
  return(List)
}
#### ME_Data_new_left: left censored (pr0: the ratio of exact event time obs.) ####
ME_Data_new_left <- function (X, beta, type = "normal", sigmae, pr0 = 0.5) 
{
  if (dim(X)[2] != dim(sigmae)[2]) 
    return("ERROR:sigmae should have the same dimension with Xstar")
  if (length(beta) != dim(X)[2]) 
    return("ERROR:length(beta) should equal to X de dimension")
  if (type != "normal" & type != "binary" & type != "poisson" & 
      type != "AFT-normal" & type != "AFT-loggamma") 
    return("ERROR:tpye set error")
  if (pr0 < 0 | pr0 > 1) 
    return("ERROR:pr0 should in (0,1)")
  p = dim(X)[2]
  n = dim(X)[1]
  xtbeta <- (t(X)) * beta
  Y = NULL
  if (type == "AFT-normal") {
    logT = NULL
    for (i in 1:n) {
      e <- rnorm(1)
      logt = sum(xtbeta[, i]) + e
      logT = cbind(logT, logt)
    }
    Y = exp(logT)
    T_true = t(Y)
    
    target_left_rate <- 1 - pr0                   # censoring ratio
    find_left_C_max <- function(max_val) {
      C_temp <- runif(n, min = 0, max = max_val)  # generate a C (uniform distribution) 
      current_rate <- mean(T_true <= C_temp)      # compute the ratio now
      return(current_rate - target_left_rate)     # return the difference the ratio
    }
    
    optimal_max_C <- uniroot(find_left_C_max, 
                             interval = c(0, max(T_true)))$root
    
    C_L <- runif(n, min = 0, max = optimal_max_C)
    Time <- pmax(T_true, C_L)
    status <- as.numeric(T_true > C_L)            # 1=Event, 0=Censored
    left_censoring_rate <- 1 - mean(status)       # check final pr0
    Time0 <- ifelse(status==1, Time, 0.00001)
    
    Y <- t(cbind(Time0,Time))
    
  }
  Xstar <- X + mvrnorm(n = n, rep(0, p), sigmae)
  List = list(response = t(Y), ME_covariate = Xstar)
  return(List)
}
#### SIMEXBoost: the original SIMEXBoost with no truncation version ####
SIMEXBoost <- function (Y, Xstar, zeta = c(0, 0.25, 0.5, 0.75, 1), B = 500, 
                        type = "normal", sigmae, Iter = 100, Lambda = 0, Extrapolation = "linear") 
{
  if (length(zeta) < 1) 
    return("ERROR:zeta length should larger than 1")
  if (B < 1) 
    return("ERROR:B should larger than 1")
  if (dim(Xstar)[2] != dim(sigmae)[2]) 
    return("ERROR:sigmae should have the same dimension with Xstar")
  if (Lambda < (-1e-05)) 
    return("ERROR:Lambda should larger than 0")
  if (type != "normal" & type != "binary" & type != "poisson" & 
      type != "AFT-normal" & type != "AFT-loggamma") 
    return("ERROR:tpye set error")
  p = dim(Xstar)[2]
  n = dim(Xstar)[1]
  betazero = (rep(0, p))
  
  if (type == "AFT-normal") {
    betarbind <- NULL
    YL = Y[, 1]
    YR = Y[, 2]
    for (cc in 1:length(zeta)) {
      betaihat <- NULL
      TT1 = YL 
      TT2 = YR 
      interval = which(TT1 == TT2)                 # no truncation
      TT1real <- TT1[interval]
      TT1censor <- TT1[-interval]
      R <- TT2[-interval]
      LR <- cbind(TT1censor, R)
      for (i in 1:B) {
        ec <- mvrnorm(n = n, rep(0, p), sigmae)
        Wetabt <- Xstar + sqrt(zeta[cc]) * ec
        Wetab <- t(Wetabt)
        time = 0
        X1 <- Wetab # Wetab[, -interval1]          # no truncation
        X1real <- X1[, interval]
        X1censor <- X1[, -interval]
        logTT1real <- log(TT1real)
        logTT1censor <- log(TT1censor)
        
        for (j in 1:Iter) {
          betazero1 = betazero
          Lbeta1 <- NULL
          for (i in 1:length(TT1censor)) {
            Lbeta <- LR[, 1][i] * exp(-sum(X1censor[, 
                                                    i] * betazero1))
            Lbeta1 <- cbind(Lbeta1, Lbeta)
          }
          Rbeta1 <- NULL
          for (i in 1:length(TT1censor)) {
            Rbeta <- LR[, 2][i] * exp(-sum(X1censor[, 
                                                    i] * betazero1))
            Rbeta1 <- cbind(Rbeta1, Rbeta)
          }
          ubetastep1 <- NULL
          dim((TT1real * (exp(-t(X1real) %*% betazero1))))
          
          ubetastep1 <- X1real %*% (logTT1real - t(X1real) %*% betazero1) - Lambda * betazero1
          
          mu_e <- 0.0
          sigma_e <- 1 
          
          # transform Lbeta1 and Rbeta1 into log form
          logLbeta <- log(Lbeta1)
          logRbeta <- log(Rbeta1)
          
          # equation: [phi(log L) - phi(log R)] / [Phi(log R) - Phi(log L)]
          denominator <- pnorm(logRbeta, mean = mu_e, sd = sigma_e) - pnorm(logLbeta, mean = mu_e, sd = sigma_e)
          
          # compute the standardized phi of e
          phi_L <- dnorm(logLbeta, mean = mu_e, sd = sigma_e)
          phi_R <- dnorm(logRbeta, mean = mu_e, sd = sigma_e)
          numerator <- mu_e * denominator + (sigma_e^2) * (phi_L - phi_R)
          
          # final result
          dFtgeneration <- numerator / denominator
          
          # If denominator is very close to 0, make it 0
          dFtgeneration[abs(denominator) < 1e-10] <- 0
          
          # make sure dFtgeneration is a vector
          dFtgeneration <- matrix(dFtgeneration, ncol = 1)
          
          for (i in 1:length(dFtgeneration)) {
            if (dFtgeneration[i] == "Inf") 
              dFtgeneration[i] = 0
            if (dFtgeneration[i] == "-Inf") 
              dFtgeneration[i] = 0
            if (dFtgeneration[i] == "NaN") 
              dFtgeneration[i] = 0
          }
          ubetastep2 <- X1censor %*% dFtgeneration - 
            Lambda * betazero1
          ubetastep <- t(cbind(ubetastep1, ubetastep2))
          u <- NULL
          for (i in 1:p) {
            u <- c(u, sum(ubetastep[, i])/length(TT1))
          }
          Delta = u
          Jset = which(abs(Delta) > 0.9 * max(abs(Delta)))
          betazero[Jset] = betazero[Jset] + 0.05 * sign(Delta[Jset])
          if (time == Iter - 1) 
            betazero[which(abs(betazero) < 0.41)] = 0
          time = time + 1
        }
        betaihat <- rbind(betaihat, betazero)
      }
      betarbind <- rbind(betarbind, betaihat)
    }
    i = 0
    meanBi <- NULL
    while ((i * B) != dim(betarbind)[1]) {
      Bi <- colMeans(betarbind[((i * B) + 1):((i + 1) * 
                                                B), ])
      meanBi <- rbind(meanBi, Bi)
      i = i + 1
    }
    for (i in 1:(length(zeta) * p)) {
      if (abs(meanBi[i]) < 0.41) 
        meanBi[i] = 0
    }
    if (Extrapolation == "linear") {
      gamma1hat <- NULL
      gamma0hat <- NULL
      for (i in 1:p) {
        x <- zeta
        y <- NULL
        for (j in 1:length(zeta)) {
          y1 <- meanBi[j, i]
          y <- c(y, y1)
        }
        c <- lm(y ~ x)
        gamma0 <- as.numeric(c$coefficients[1])
        gamma1 <- as.numeric(c$coefficients[2])
        gamma0hat <- c(gamma0hat, gamma0)
        gamma1hat <- c(gamma1hat, gamma1)
      }
      betacorrect <- gamma0hat - gamma1hat
    }
    if (Extrapolation == "quadratic") {
      gamma1hat <- NULL
      gamma0hat <- NULL
      gamma2hat <- NULL
      for (i in 1:p) {
        x <- zeta
        y <- NULL
        for (j in 1:length(zeta)) {
          y1 <- meanBi[j, i]
          y <- c(y, y1)
        }
        c <- lm(y ~ x + I(x * x))
        gamma0 <- as.numeric(c$coefficients[1])
        gamma1 <- as.numeric(c$coefficients[2])
        gamma2 <- as.numeric(c$coefficients[3])
        gamma0hat <- c(gamma0hat, gamma0)
        gamma1hat <- c(gamma1hat, gamma1)
        gamma2hat <- c(gamma2hat, gamma2)
      }
      betacorrect <- gamma0hat - gamma1hat + gamma2hat
    }
    for (i in 1:p) {
      if (abs(betacorrect[i]) < 0.41) 
        betacorrect[i] = 0
    }
  }
  return(list(BetaHatCorrect = betacorrect))
}
#### SIMEXBoost2: (only change AFT-normal) use betahat in Step 1 to initialize "betazero ####

# update all variables in each iteration 
# use betahat in Step 1 to initialize "betazero" 
SIMEXBoost2 <- function (Y, Xstar, zeta = c(0, 0.25, 0.5, 0.75, 1), B = 500, 
                         type = "normal", sigmae, Iter = 100, Lambda = 0, Extrapolation = "linear", betazero=(rep(0, dim(Xstar)[2]))) 
{
  if (length(zeta) < 1) 
    return("ERROR:zeta length should larger than 1")
  if (B < 1) 
    return("ERROR:B should larger than 1")
  if (dim(Xstar)[2] != dim(sigmae)[2]) 
    return("ERROR:sigmae should have the same dimension with Xstar")
  if (Lambda < (-1e-05)) 
    return("ERROR:Lambda should larger than 0")
  if (type != "normal" & type != "binary" & type != "poisson" & 
      type != "AFT-normal" & type != "AFT-loggamma") 
    return("ERROR:tpye set error")
  p = dim(Xstar)[2]
  n = dim(Xstar)[1]
  
  if (type == "AFT-normal") {
    betarbind <- NULL
    YL = Y[, 1]
    YR = Y[, 2]
    for (cc in 1:length(zeta)) {
      betaihat <- NULL
      TT1 = YL 
      TT2 = YR 
      interval = which(TT1 == TT2)  
      TT1real <- TT1[interval]
      TT1censor <- TT1[-interval]
      R <- TT2[-interval]
      LR <- cbind(TT1censor, R)
      for (i in 1:B) {
        ec <- mvrnorm(n = n, rep(0, p), sigmae)
        Wetabt <- Xstar + sqrt(zeta[cc]) * ec
        Wetab <- t(Wetabt)
        time = 0
        X1 <- Wetab # Wetab[, -interval1]          # no truncation
        X1real <- X1[, interval]
        X1censor <- X1[, -interval]
        logTT1real <- log(TT1real)
        logTT1censor <- log(TT1censor)
        
        for (j in 1:Iter) {
          betazero1 = betazero
          Lbeta1 <- NULL
          for (i in 1:length(TT1censor)) {
            Lbeta <- LR[, 1][i] * exp(-sum(X1censor[, 
                                                    i] * betazero1))
            Lbeta1 <- cbind(Lbeta1, Lbeta)
          }
          Rbeta1 <- NULL
          for (i in 1:length(TT1censor)) {
            Rbeta <- LR[, 2][i] * exp(-sum(X1censor[, 
                                                    i] * betazero1))
            Rbeta1 <- cbind(Rbeta1, Rbeta)
          }
          ubetastep1 <- NULL
          dim((TT1real * (exp(-t(X1real) %*% betazero1))))
          
          ubetastep1 <- X1real %*% (logTT1real - t(X1real) %*% betazero1) - Lambda * betazero1
          
          mu_e <- 0.0
          sigma_e <- 1 #sqrt(sigmae[1,1])
          
          # transform Lbeta1 and Rbeta1 into log form
          logLbeta <- log(Lbeta1)
          logRbeta <- log(Rbeta1)
          
          # equation: [phi(log L) - phi(log R)] / [Phi(log R) - Phi(log L)]
          denominator <- pnorm(logRbeta, mean = mu_e, sd = sigma_e) - pnorm(logLbeta, mean = mu_e, sd = sigma_e)
          
          # compute the standardized phi of e
          phi_L <- dnorm(logLbeta, mean = mu_e, sd = sigma_e)
          phi_R <- dnorm(logRbeta, mean = mu_e, sd = sigma_e)
          numerator <- mu_e * denominator + (sigma_e^2) * (phi_L - phi_R)
          
          # final result
          dFtgeneration <- numerator / denominator
          
          # If denominator is very close to 0, make it 0
          dFtgeneration[abs(denominator) < 1e-10] <- 0
          
          # make sure dFtgeneration is a vector
          dFtgeneration <- matrix(dFtgeneration, ncol = 1)
          
          for (i in 1:length(dFtgeneration)) {
            if (dFtgeneration[i] == "Inf") 
              dFtgeneration[i] = 0
            if (dFtgeneration[i] == "-Inf") 
              dFtgeneration[i] = 0
            if (dFtgeneration[i] == "NaN") 
              dFtgeneration[i] = 0
          }
          ubetastep2 <- X1censor %*% dFtgeneration - 
            Lambda * betazero1
          ubetastep <- t(cbind(ubetastep1, ubetastep2))
          u <- NULL
          for (i in 1:p) {
            u <- c(u, sum(ubetastep[, i])/length(TT1))
          }
          Delta = u
          Jset = which(abs(Delta) > 0.9 * max(abs(Delta)))
          betazero[Jset] = betazero[Jset] + 0.05 * sign(Delta[Jset])
          if (time == Iter - 1) 
            betazero[which(abs(betazero) < 0.41)] = 0
          time = time + 1
        }
        betaihat <- rbind(betaihat, betazero)
      }
      betarbind <- rbind(betarbind, betaihat)
    }
    i = 0
    meanBi <- NULL
    while ((i * B) != dim(betarbind)[1]) {
      Bi <- colMeans(betarbind[((i * B) + 1):((i + 1) * 
                                                B), ])
      meanBi <- rbind(meanBi, Bi)
      i = i + 1
    }
    for (i in 1:(length(zeta) * p)) {
      if (abs(meanBi[i]) < 0.41) 
        meanBi[i] = 0
    }
    if (Extrapolation == "linear") {
      gamma1hat <- NULL
      gamma0hat <- NULL
      for (i in 1:p) {
        x <- zeta
        y <- NULL
        for (j in 1:length(zeta)) {
          y1 <- meanBi[j, i]
          y <- c(y, y1)
        }
        c <- lm(y ~ x)
        gamma0 <- as.numeric(c$coefficients[1])
        gamma1 <- as.numeric(c$coefficients[2])
        gamma0hat <- c(gamma0hat, gamma0)
        gamma1hat <- c(gamma1hat, gamma1)
      }
      betacorrect <- gamma0hat - gamma1hat
    }
    if (Extrapolation == "quadratic") {
      gamma1hat <- NULL
      gamma0hat <- NULL
      gamma2hat <- NULL
      for (i in 1:p) {
        x <- zeta
        y <- NULL
        for (j in 1:length(zeta)) {
          y1 <- meanBi[j, i]
          y <- c(y, y1)
        }
        c <- lm(y ~ x + I(x * x))
        gamma0 <- as.numeric(c$coefficients[1])
        gamma1 <- as.numeric(c$coefficients[2])
        gamma2 <- as.numeric(c$coefficients[3])
        gamma0hat <- c(gamma0hat, gamma0)
        gamma1hat <- c(gamma1hat, gamma1)
        gamma2hat <- c(gamma2hat, gamma2)
      }
      betacorrect <- gamma0hat - gamma1hat + gamma2hat
    }
    for (i in 1:p) {
      if (abs(betacorrect[i]) < 0.41) 
        betacorrect[i] = 0
    }
  }
  return(list(BetaHatCorrect = betacorrect))
}


#### SIMEXBoost3: (only change AFT-normal) Naive (no error correction)####
# Naive (no error correction) 
SIMEXBoost3 <- function (Y, Xstar, zeta = c(0, 0), B = 500, 
                         type = "normal", sigmae, Iter = 100, Lambda = 0, Extrapolation = "linear") 
{
  if (length(zeta) < 1) 
    return("ERROR:zeta length should larger than 1")
  if (B < 1) 
    return("ERROR:B should larger than 1")
  if (dim(Xstar)[2] != dim(sigmae)[2]) 
    return("ERROR:sigmae should have the same dimension with Xstar")
  if (Lambda < (-1e-05)) 
    return("ERROR:Lambda should larger than 0")
  if (type != "normal" & type != "binary" & type != "poisson" & 
      type != "AFT-normal" & type != "AFT-loggamma") 
    return("ERROR:tpye set error")
  p = dim(Xstar)[2]
  n = dim(Xstar)[1]
  betazero = (rep(0, p))
  
  if (type == "AFT-normal") {
    betarbind <- NULL
    YL = Y[, 1]
    YR = Y[, 2]
    for (cc in 1:length(zeta)) {
      betaihat <- NULL
      TT1 = YL 
      TT2 = YR 
      
      interval = which(TT1 == TT2)                 # no truncation
      TT1real <- TT1[interval]
      TT1censor <- TT1[-interval]
      R <- TT2[-interval]
      LR <- cbind(TT1censor, R)
      for (i in 1:B) {
        ec <- mvrnorm(n = n, rep(0, p), sigmae)
        Wetabt <- Xstar + sqrt(zeta[cc]) * ec
        Wetab <- t(Wetabt)
        time = 0
        X1 <- Wetab # Wetab[, -interval1]          # no truncation
        X1real <- X1[, interval]
        X1censor <- X1[, -interval]
        logTT1real <- log(TT1real)
        logTT1censor <- log(TT1censor)
        
        for (j in 1:Iter) {
          betazero1 = betazero
          Lbeta1 <- NULL
          for (i in 1:length(TT1censor)) {
            Lbeta <- LR[, 1][i] * exp(-sum(X1censor[, 
                                                    i] * betazero1))
            Lbeta1 <- cbind(Lbeta1, Lbeta)
          }
          Rbeta1 <- NULL
          for (i in 1:length(TT1censor)) {
            Rbeta <- LR[, 2][i] * exp(-sum(X1censor[, 
                                                    i] * betazero1))
            Rbeta1 <- cbind(Rbeta1, Rbeta)
          }
          ubetastep1 <- NULL
          dim((TT1real * (exp(-t(X1real) %*% betazero1))))
          
          ubetastep1 <- X1real %*% (logTT1real - t(X1real) %*% betazero1) - Lambda * betazero1
          
          mu_e <- 0.0
          sigma_e <- 1 #sqrt(sigmae[1,1])
          
          # transform Lbeta1 and Rbeta1 into log form
          logLbeta <- log(Lbeta1)
          logRbeta <- log(Rbeta1)
          
          # equation: [phi(log L) - phi(log R)] / [Phi(log R) - Phi(log L)]
          denominator <- pnorm(logRbeta, mean = mu_e, sd = sigma_e) - pnorm(logLbeta, mean = mu_e, sd = sigma_e)
          
          # compute the standardized phi of e
          phi_L <- dnorm(logLbeta, mean = mu_e, sd = sigma_e)
          phi_R <- dnorm(logRbeta, mean = mu_e, sd = sigma_e)
          numerator <- mu_e * denominator + (sigma_e^2) * (phi_L - phi_R)
          
          # final result
          dFtgeneration <- numerator / denominator
          
          # If denominator is very close to 0, make it 0
          dFtgeneration[abs(denominator) < 1e-10] <- 0
          
          # make sure dFtgeneration is a vector
          dFtgeneration <- matrix(dFtgeneration, ncol = 1)
          
          for (i in 1:length(dFtgeneration)) {
            if (dFtgeneration[i] == "Inf") 
              dFtgeneration[i] = 0
            if (dFtgeneration[i] == "-Inf") 
              dFtgeneration[i] = 0
            if (dFtgeneration[i] == "NaN") 
              dFtgeneration[i] = 0
          }
          ubetastep2 <- X1censor %*% dFtgeneration - 
            Lambda * betazero1
          ubetastep <- t(cbind(ubetastep1, ubetastep2))
          u <- NULL
          for (i in 1:p) {
            u <- c(u, sum(ubetastep[, i])/length(TT1))
          }
          Delta = u
          Jset = which(abs(Delta) > 0.9 * max(abs(Delta)))
          betazero[Jset] = betazero[Jset] + 0.05 * sign(Delta[Jset])
          if (time == Iter - 1) 
            betazero[which(abs(betazero) < 0.41)] = 0
          time = time + 1
        }
        betaihat <- rbind(betaihat, betazero)
      }
      betarbind <- rbind(betarbind, betaihat)
    }
    i = 0
    meanBi <- NULL
    while ((i * B) != dim(betarbind)[1]) {
      Bi <- colMeans(betarbind[((i * B) + 1):((i + 1) * 
                                                B), ])
      meanBi <- rbind(meanBi, Bi)
      i = i + 1
    }
    for (i in 1:(length(zeta) * p)) {
      if (abs(meanBi[i]) < 0.41) 
        meanBi[i] = 0
    }
    
    betacorrect <- meanBi[1, ]
    
    for (i in 1:p) {
      if (abs(betacorrect[i]) < 0.41) 
        betacorrect[i] = 0
    }
  }
  return(list(BetaHatCorrect = betacorrect))
}

#### SIMEXBoost4: (only change AFT-normal) Naive -- step 2: update all variables in each iteration####
#Naive -- step 2: update all variables in each iteration 

SIMEXBoost4 <- function (Y, Xstar, zeta = c(0, 0), B = 500, 
                         type = "normal", sigmae, Iter = 100, Lambda = 0, Extrapolation = "linear", betazero=(rep(0, dim(Xstar)[2]))) 
{
  if (length(zeta) < 1) 
    return("ERROR:zeta length should larger than 1")
  if (B < 1) 
    return("ERROR:B should larger than 1")
  if (dim(Xstar)[2] != dim(sigmae)[2]) 
    return("ERROR:sigmae should have the same dimension with Xstar")
  if (Lambda < (-1e-05)) 
    return("ERROR:Lambda should larger than 0")
  if (type != "normal" & type != "binary" & type != "poisson" & 
      type != "AFT-normal" & type != "AFT-loggamma") 
    return("ERROR:tpye set error")
  p = dim(Xstar)[2]
  n = dim(Xstar)[1]
  
  if (type == "AFT-normal") {
    betarbind <- NULL
    YL = Y[, 1]
    YR = Y[, 2]
    for (cc in 1:length(zeta)) {
      betaihat <- NULL
      TT1 = YL 
      TT2 = YR 
      
      interval = which(TT1 == TT2)                 # no truncation
      TT1real <- TT1[interval]
      TT1censor <- TT1[-interval]
      R <- TT2[-interval]
      LR <- cbind(TT1censor, R)
      for (i in 1:B) {
        ec <- mvrnorm(n = n, rep(0, p), sigmae)
        Wetabt <- Xstar + sqrt(zeta[cc]) * ec
        Wetab <- t(Wetabt)
        time = 0
        X1 <- Wetab # Wetab[, -interval1]          # no truncation
        X1real <- X1[, interval]
        X1censor <- X1[, -interval]
        logTT1real <- log(TT1real)
        logTT1censor <- log(TT1censor)
        
        for (j in 1:Iter) {
          betazero1 = betazero
          Lbeta1 <- NULL
          for (i in 1:length(TT1censor)) {
            Lbeta <- LR[, 1][i] * exp(-sum(X1censor[, 
                                                    i] * betazero1))
            Lbeta1 <- cbind(Lbeta1, Lbeta)
          }
          Rbeta1 <- NULL
          for (i in 1:length(TT1censor)) {
            Rbeta <- LR[, 2][i] * exp(-sum(X1censor[, 
                                                    i] * betazero1))
            Rbeta1 <- cbind(Rbeta1, Rbeta)
          }
          ubetastep1 <- NULL
          dim((TT1real * (exp(-t(X1real) %*% betazero1))))
          
          ubetastep1 <- X1real %*% (logTT1real - t(X1real) %*% betazero1) - Lambda * betazero1
          
          mu_e <- 0.0
          sigma_e <- 1 #sqrt(sigmae[1,1])
          
          # transform Lbeta1 and Rbeta1 into log form
          logLbeta <- log(Lbeta1)
          logRbeta <- log(Rbeta1)
          
          # equation: [phi(log L) - phi(log R)] / [Phi(log R) - Phi(log L)]
          denominator <- pnorm(logRbeta, mean = mu_e, sd = sigma_e) - pnorm(logLbeta, mean = mu_e, sd = sigma_e)
          
          # compute the standardized phi of e
          phi_L <- dnorm(logLbeta, mean = mu_e, sd = sigma_e)
          phi_R <- dnorm(logRbeta, mean = mu_e, sd = sigma_e)
          numerator <- mu_e * denominator + (sigma_e^2) * (phi_L - phi_R)
          
          # final result
          dFtgeneration <- numerator / denominator
          
          # If denominator is very close to 0, make it 0
          dFtgeneration[abs(denominator) < 1e-10] <- 0
          
          # make sure dFtgeneration is a vector
          dFtgeneration <- matrix(dFtgeneration, ncol = 1)
          
          for (i in 1:length(dFtgeneration)) {
            if (dFtgeneration[i] == "Inf") 
              dFtgeneration[i] = 0
            if (dFtgeneration[i] == "-Inf") 
              dFtgeneration[i] = 0
            if (dFtgeneration[i] == "NaN") 
              dFtgeneration[i] = 0
          }
          ubetastep2 <- X1censor %*% dFtgeneration - 
            Lambda * betazero1
          ubetastep <- t(cbind(ubetastep1, ubetastep2))
          u <- NULL
          for (i in 1:p) {
            u <- c(u, sum(ubetastep[, i])/length(TT1))
          }
          Delta = u
          Jset = which(abs(Delta) > 0.9 * max(abs(Delta)))              
          betazero[Jset] = betazero[Jset] + 0.05 * sign(Delta[Jset])
          if (time == Iter - 1) 
            betazero[which(abs(betazero) < 0.41)] = 0
          time = time + 1
        }
        betaihat <- rbind(betaihat, betazero)
      }
      betarbind <- rbind(betarbind, betaihat)
    }
    i = 0
    meanBi <- NULL
    while ((i * B) != dim(betarbind)[1]) {
      Bi <- colMeans(betarbind[((i * B) + 1):((i + 1) * 
                                                B), ])
      meanBi <- rbind(meanBi, Bi)
      i = i + 1
    }
    for (i in 1:(length(zeta) * p)) {
      if (abs(meanBi[i]) < 0.41) 
        meanBi[i] = 0
    }

    betacorrect <- meanBi[1, ]
    
    for (i in 1:p) {
      if (abs(betacorrect[i]) < 0.41) 
        betacorrect[i] = 0
    }
  }
  return(list(BetaHatCorrect = betacorrect))
}
