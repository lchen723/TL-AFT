#### LL_func ####
LL_func <- function(Y0_V, Xstar0_V, beta_hat, sigma = 1, sigma_e_matrix){
  
  extra_variance <- t(beta_hat) %*% sigma_e_matrix %*% beta_hat
  sigma_new <- sqrt(sigma^2 + as.numeric(extra_variance))
  
  # 1. 計算線性預測值 (Vectorized)
  mu <- Xstar0_V %*% matrix(beta_hat, ncol = 1)
  
  # 2. 取得上下界並標準化 (Standardize by sigma)
  # 假設模型: log(Y) = X*beta + sigma*error
  z_low <- (log(Y0_V[,1]) - mu) / sigma_new
  z_upp <- (log(Y0_V[,2]) - mu) / sigma_new
  
  # 3. 判斷受限類型 (Exact vs Interval)
  # 建議加入 tolerance 避免浮點數誤差，例如 abs(y2-y1) < 1e-8
  delta <- ifelse(Y0_V[,1] == Y0_V[,2], 1, 0)
  
  # 初始化 Log-Likelihood 向量
  ll_vec <- numeric(length(delta))
  
  # --- Case A: Exact Observations (delta == 1) ---
  # PDF contribution: (1/sigma) * phi(z)
  # Log-scale: log(dnorm(z)) - log(sigma)
  # 注意: 如果是對 log(Y) 建模，這就是針對 log(Y) 的密度。
  # 如果原變數是 Y，嚴格來說還要減去 log(Y) (Jacobian)，但這不影響 beta 的最佳化，可忽略。
  if(any(delta == 1)){
    idx <- which(delta == 1)
    ll_vec[idx] <- dnorm(z_low[idx], log = TRUE) - log(sigma_new)
  }
  
  # --- Case B: Interval Censored (delta == 0) ---
  # Probability contribution: Phi(z_upp) - Phi(z_low)
  if(any(delta == 0)){
    idx <- which(delta == 0)
    prob_diff <- pnorm(z_upp[idx]) - pnorm(z_low[idx])
    
    # 數值穩定性處理：避免 log(0)
    # 使用 pmax 確保機率至少有 Machine Epsilon，防止 -Inf
    ll_vec[idx] <- log(pmax(prob_diff, .Machine$double.eps))
  }
  
  # 4. 回傳總和
  return(sum(ll_vec))
}

#### find out the informative sources ####

# library("SIMEXBoost")
library("MASS")
starting_time <- Sys.time()


#### set the target and the source data ####

p0 <- 100
n0 <- 100
n <- rep(100,10)#c(100,100,100,100,100,100,100,100,100,100)
K <- length(n)
#TT <- 5
beta_set <- c(1,1,1,rep(0,p0-3))
beta_set2 <- c(0,1,1,1,0,0,rep(0, p0-6))


X0 <- matrix(rnorm((p0)*n0),nrow=n0,ncol=p0,byrow=TRUE)
data0=ME_Data_new(X0,beta=beta_set,pr0=0.2,
              type="AFT-normal",
              sigmae=diag(0.25,p0))
Y0 <- data0$response
Xstar0 = data0$ME_covariate


X <- NULL
data <- NULL
Y <- NULL
Xstar <- NULL

for(k in 1:K){
  X[[k]] <- matrix(rnorm((p0)*n[k]),nrow=n[k],ncol=p0,byrow=TRUE)
}

AI <- 5# number of informative sources
for(k in 1:K){
  
  if(k<=AI){
    data[[k]] <- ME_Data_new(X[[k]],beta=beta_set,pr0=0.2,
                         type="AFT-normal",
                         sigmae=diag(0.25,p0))
  }else{
    data[[k]] <- ME_Data_new(X[[k]],beta=beta_set2,pr0=0.2,
                         type="AFT-normal",
                         sigmae=diag(0.25,p0))
  }
  
  Y[[k]] <- data[[k]]$response
  Xstar[[k]] = data[[k]]$ME_covariate
  
}


#### Informative sources detection ####

#### Separate X0 into 4 approximately equal size ####
R <- 4
ind <- NULL
for(r in 1:R){
  if(r==R){
    ind[[r]] <- ((r-1)*round(n0/R)+1):n0
  }else{
    ind[[r]] <- ((r-1)*round(n0/R)+1):(r*round(n0/R))
  }
}

LL <- matrix(rep(NA,(K*R)),ncol=R)
IBS_value <- matrix(rep(NA,(K*R)),ncol=R)
model1_store <- array(NA, c(K,R,p0))
model2_store <- array(NA, c(K,R,p0))
#### combine source data ####
for(k in 1:K){
  
  for(r in 1:R){
    
    Y0_T <- Y0[-ind[[r]],]
    Y0_V <- Y0[ ind[[r]],]
    Xstar0_T <- Xstar0[-ind[[r]],]
    Xstar0_V <- Xstar0[ ind[[r]],]
    
    
    Y_raw <- NULL
    Xstar_raw <- NULL
    
    Y_raw <- Y[[k]]
    Xstar_raw <- Xstar[[k]]
    
    Y_all <- rbind(Y0_T, Y_raw)
    Xstar_all <- rbind(Xstar0_T, Xstar_raw)
    
    
    #### Step 1 AND choose the variables ####
    model1 <- SIMEXBoost(Y_all,Xstar_all,B=100,zeta=c(0, 0.25, 0.50, 0.75, 1),
                         type="AFT-normal",Iter=20,sigmae=diag(0.25,p0))
    model1$BetaHatCorrect
    model1_store[k,r,] <- model1$BetaHatCorrect
    
    #### Step 2 ####
    covariates <- which(model1$BetaHatCorrect!=0)
    new_p <- length(covariates)
    Xstar0_step2 <- Xstar0_T[,covariates]
    beta_step1 <- model1$BetaHatCorrect[covariates]
    
    model2 <- SIMEXBoost2(Y0_T,Xstar0_step2,B=100,zeta=c(0, 0.25, 0.50, 0.75, 1),
                          type="AFT-normal",Iter=20,sigmae=diag(0.25,new_p),betazero=beta_step1)
    model2_all <- rep(0,p0)
    model2_all[covariates] <- model2$BetaHatCorrect
    model2_store[k,r,] <- model2_all
    
    #### see if yhat is in the interval Y0_V ####
    #yhat <- exp(Xstar0_V %*% matrix(model2_all,ncol=1))
    LL[k, r] <- LL_func(Y0_V=Y0_V, Xstar0_V=Xstar0_V, beta_hat=model2_store[k,r,], sigma_e_matrix = diag(0.25, p0))
    
    IBS_value[k, r] <- IBS_func(betahat=model2_store[k,r,], Y0_V=Y0_V, Xstar0_V=Xstar0_V)
    
  }
  
}

LL_0 <- rep(NA, R)
IBS_value_0 <- rep(NA, R)
model0_store <- array(NA, c(R,p0))
for(r in 1:R){
  
  Y0_T <- Y0[-ind[[r]],]
  Y0_V <- Y0[ ind[[r]],]
  Xstar0_T <- Xstar0[-ind[[r]],]
  Xstar0_V <- Xstar0[ ind[[r]],]
  
  model1 <- SIMEXBoost(Y0_T,Xstar0_T,B=100,zeta=c(0, 0.25, 0.50, 0.75, 1),
                       type="AFT-normal",Iter=20,sigmae=diag(0.25,p0))
  
  model2_all <- model1$BetaHatCorrect
  model0_store[r,] <- model2_all
  #### see if yhat is in the interval Y0_V ####
  #yhat <- exp(Xstar0_V %*% matrix(model2_all,ncol=1))
  LL_0[r] <- LL_func(Y0_V=Y0_V, Xstar0_V=Xstar0_V, beta_hat=model0_store[r,], sigma_e_matrix = diag(0.25, p0))

  IBS_value_0[r] <- IBS_func(betahat=model0_store[r,], Y0_V=Y0_V, Xstar0_V=Xstar0_V)
}


ending_time <- Sys.time()

ending_time - starting_time


(rowMeans(LL) - mean(LL_0))/sd(LL_0)

count <- rep(NA, K)
for(k in 1:K){
  count[k] <- sum((LL_0 - LL[k,]) < 0)
}
which(count>=3)

gain <- rep(NA, K)
for(k in 1:K){
  gain_0 <- (mean(LL[k,]) - mean(LL_0))/abs(mean(LL_0))
  gain[k] <- print(gain_0)
}

# 
# (mean(IBS_value_0) - rowMeans(IBS_value))/sd(IBS_value_0)
# 
# count <- rep(NA, K)
# for(k in 1:K){
#   count[k] <- sum((IBS_value_0 - IBS_value[k,]) > 0)
# }
# which(count>=3)
# 
# for(k in 1:K){
#   gain <- (mean(IBS_value_0) - mean(IBS_value[k,]))/mean(IBS_value_0)
#   print(gain)
# }


#setwd("/Users/jcwu/Documents/！paper/TL_interval-censored/simulation_store_RData")
#save.image(file="tmp_infor_20251212_25left.RData")
