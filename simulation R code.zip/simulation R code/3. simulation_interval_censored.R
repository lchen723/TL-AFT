#### simulation 看起來是初版的模擬code ####

#### use them on the interval/right/left censored data ####

setwd("/Users/jcwu/Documents/！paper/TL_interval-censored/simulation_store_RData/interval-censored")

# setwd("/Users/rjwu/Downloads/store RData")
# setwd("C:/Users/User/Documents/RJ/survival/interval-censored")
#### Set the verifying values e.g. L2-norm ####

sigmae_set <- 0.25 # c(0.25, 0.50, 0.75)

p0 <- 100
n0 <- 200
n <- rep(100, 10)
K <- length(n)

TT <- 10

beta_set <- c(1,1,1,rep(0,p0-3))
beta_set2 <- c(0,1,1,1,0,0,rep(0, p0-6))


#### B=100, Iter=20, zeta=c(0.00, 0.25, 0.50, 0.75, 1.00) ####
#### Check: X1 in {0, 1} --> okay!
#### X~MVN 
#### 跑informative 的時候，真正去跑，看看結果如何 (真跑！）####


#install.packages("SIMEXBoost")
#library("SIMEXBoost")
library("MASS")

starting_time <- Sys.time()
#setwd("/Users/jcwu/Documents/！paper/TL_interval-censored/simulation_trying_dataset")
#load(file="trying_dataset.RData")


model0_par <- matrix(rep(0,TT*p0),ncol=p0)
model1_par <- matrix(rep(0,TT*p0),ncol=p0) # TL: step 1
model2_par <- matrix(rep(0,TT*p0),ncol=p0) # TL: step 2 

# compare to other methods
model3_par <- matrix(rep(0,TT*p0),ncol=p0)
model4_par <- matrix(rep(0,TT*p0),ncol=p0)

# all sources TL 
model5_par <- matrix(rep(0,TT*p0),ncol=p0)
model6_par <- matrix(rep(0,TT*p0),ncol=p0)

# all source Naive
model7_par <- matrix(rep(0,TT*p0),ncol=p0)
model8_par <- matrix(rep(0,TT*p0),ncol=p0)


L2norm_store <- rep(NA, 5)
L1norm_store <- rep(NA, 5)
S <- rep(NA, 5)
FN <- rep(NA, 5)
Sen <- rep(NA, 5)
Spe <- rep(NA, 5)

d_out_bar_store <- NULL
informative_source_store <- NULL


for(t in 1:TT){
  #### Data generation ####
  
  X0 <- matrix(rnorm((p0)*n0),nrow=n0,ncol=p0,byrow=TRUE)
  data0=ME_Data_new(X0,beta=beta_set,pr0=0.2, 
                          type="AFT-normal",
                          sigmae=diag(sigmae_set,p0))
  Y0 <- data0$response
  Xstar0 = data0$ME_covariate
  
  
  X <- NULL
  data <- NULL
  Y <- NULL
  Xstar <- NULL
  
  for(k in 1:K){
    X[[k]] <- matrix(rnorm((p0)*n[k]),nrow=n[k],ncol=p0,byrow=TRUE)
  }
  
  AI <- 5 # number of informative sources
  
  for(k in 1:K){
    
    if(k<=AI){
      data[[k]] <- ME_Data_new(X[[k]],beta=beta_set,pr0=0.2, # the value of pr0 is not matter, we change the code inside
                                     type="AFT-normal",
                                     sigmae=diag(sigmae_set,p0))
    }else{
      data[[k]] <- ME_Data_new(X[[k]],beta=beta_set2,pr0=0.2, # the value of pr0 is not matter, we change the code inside
                                     type="AFT-normal",
                                     sigmae=diag(sigmae_set,p0))
    }
    
    Y[[k]] <- data[[k]]$response
    Xstar[[k]] = data[[k]]$ME_covariate
    
  }
  
  
  #### THE BEGINNING of informative source chosen  ####
  
  informative_source <- 1:AI
  
  #### THE BEGINNING of TL ####
  
  #### fit on only target data ####
  model0 <- 
    SIMEXBoost(Y0,Xstar0,B=100,zeta=c(0,0.25,0.5,0.75,1),
               type="AFT-normal",Iter=20,sigmae=diag(sigmae_set,p0))
  
  
  #### combine informative source data ####
  Y_raw <- NULL
  Xstar_raw <- NULL
  for(k in informative_source){
    Y_raw <- rbind(Y_raw, Y[[k]])
    Xstar_raw <- rbind(Xstar_raw, Xstar[[k]])
  }
  
  Y_all <- rbind(Y0, Y_raw)
  Xstar_all <- rbind(Xstar0, Xstar_raw)
  
  #### Step 1 AND choose the variables ####
  model1 <- SIMEXBoost(Y_all,Xstar_all,B=100,zeta=c(0,0.25,0.5,0.75,1),
                       type="AFT-normal",Iter=20,sigmae=diag(sigmae_set,p0))
  
  #### Step 2 ####
  covariates <- which(model1$BetaHatCorrect!=0)
  new_p <- length(covariates)
  Xstar0_step2 <- Xstar0[,covariates]
  beta_step1 <- model1$BetaHatCorrect[covariates]
  
  model2 <- SIMEXBoost2(Y0,Xstar0_step2,B=100,zeta=c(0,0.25,0.5,0.75,1),
                        type="AFT-normal",Iter=20,sigmae=diag(sigmae_set,new_p),betazero=beta_step1)
  model2_all <- rep(0,p0)
  model2_all[covariates] <- model2$BetaHatCorrect
  
  #### Naive Step 1 ####
  model3 <- SIMEXBoost3(Y_all,Xstar_all,B=100,zeta=c(0,0),
                        type="AFT-normal",Iter=20,sigmae=diag(sigmae_set,p0))
  
  #### Naive Step 2 ####
  covariates <- which(model3$BetaHatCorrect!=0)
  new_p <- length(covariates)
  Xstar0_step2 <- Xstar0[,covariates]
  beta_step3 <- model3$BetaHatCorrect[covariates]
  
  model4 <- SIMEXBoost4(Y0,Xstar0_step2,B=100,zeta=c(0,0),
                        type="AFT-normal",Iter=20,sigmae=diag(sigmae_set,new_p),betazero=beta_step3)
  model4_all <- rep(0,p0)
  model4_all[covariates] <- model4$BetaHatCorrect
  
  
  #### combine all source data ####
  Y_raw <- NULL
  Xstar_raw <- NULL
  for(k in 1:K){
    Y_raw <- rbind(Y_raw, Y[[k]])
    Xstar_raw <- rbind(Xstar_raw, Xstar[[k]])
  }
  
  Y_all <- rbind(Y0, Y_raw)
  Xstar_all <- rbind(Xstar0, Xstar_raw)
  
  #### Step 1 AND choose the variables ####
  model5 <- SIMEXBoost(Y_all,Xstar_all,B=100,zeta=c(0,0.25,0.5,0.75,1),
                       type="AFT-normal",Iter=20,sigmae=diag(sigmae_set,p0))
  
  #### Step 2 ####
  covariates <- which(model5$BetaHatCorrect!=0)
  new_p <- length(covariates)
  Xstar0_step2 <- Xstar0[,covariates]
  beta_step5 <- model5$BetaHatCorrect[covariates]
  
  model6 <- SIMEXBoost2(Y0,Xstar0_step2,B=100,zeta=c(0,0.25,0.5,0.75,1),
                        type="AFT-normal",Iter=20,sigmae=diag(sigmae_set,new_p),betazero=beta_step5)
  model6_all <- rep(0,p0)
  model6_all[covariates] <- model6$BetaHatCorrect
  
  #### Naive Step 1 ####
  model7 <- SIMEXBoost3(Y_all,Xstar_all,B=100,zeta=c(0,0),
                        type="AFT-normal",Iter=20,sigmae=diag(sigmae_set,p0))
  
  #### Naive Step 2 ####
  covariates <- which(model7$BetaHatCorrect!=0)
  new_p <- length(covariates)
  Xstar0_step2 <- Xstar0[,covariates]
  beta_step7 <- model7$BetaHatCorrect[covariates]
  
  model8 <- SIMEXBoost4(Y0,Xstar0_step2,B=100,zeta=c(0,0),
                        type="AFT-normal",Iter=20,sigmae=diag(sigmae_set,new_p),betazero=beta_step7)
  model8_all <- rep(0,p0)
  model8_all[covariates] <- model8$BetaHatCorrect
  
  
  #### START to store items ####
  model0_par[t,] <- model0$BetaHatCorrect
  
  model1_par[t,] <- model1$BetaHatCorrect
  model2_par[t,] <- model2_all
  
  model3_par[t,] <- model3$BetaHatCorrect
  model4_par[t,] <- model4_all
  
  model5_par[t,] <- model5$BetaHatCorrect
  model6_par[t,] <- model6_all
  
  model7_par[t,] <- model7$BetaHatCorrect
  model8_par[t,] <- model8_all
  
  
}


#### change here
store_S <- matrix(rep(NA, TT*5),ncol=5)
store_FN <- matrix(rep(NA, TT*5),ncol=5)
store_SEN <- matrix(rep(NA, TT*5),ncol=5)
store_SPE <- matrix(rep(NA, TT*5),ncol=5)

for(t in 1:TT){
  # store_L2norm[t,1] <- sum((model2_par[t,]-beta_set)^2) 
  # store_L2norm[t,2] <- sum((model4_par[t,]-beta_set)^2) 
  # store_L2norm[t,3] <- sum((model6_par[t,]-beta_set)^2) 
  # store_L2norm[t,4] <- sum((model8_par[t,]-beta_set)^2) 
  # store_L2norm[t,5] <- sum((model0_par[t,]-beta_set)^2) 
  # 
  # store_L1norm[t,1] <- sum(abs(model2_par[t,]-beta_set)) 
  # store_L1norm[t,2] <- sum(abs(model4_par[t,]-beta_set))
  # store_L1norm[t,3] <- sum(abs(model6_par[t,]-beta_set))
  # store_L1norm[t,4] <- sum(abs(model8_par[t,]-beta_set))
  # store_L1norm[t,5] <- sum(abs(model0_par[t,]-beta_set))
  
  #### S: the number of selected covariates ####
  store_S[t,1] <- length(which(model2_par[t,]!=0))
  store_S[t,2] <- length(which(model4_par[t,]!=0))
  store_S[t,3] <- length(which(model6_par[t,]!=0))
  store_S[t,4] <- length(which(model8_par[t,]!=0))
  store_S[t,5] <- length(which(model0_par[t,]!=0))
  
  #### FN: the number of falsely excluded covariates ####
  store_FN[t,1] <- 3-sum(which(model2_par[t,]!=0)<=3)
  store_FN[t,2] <- 3-sum(which(model4_par[t,]!=0)<=3)
  store_FN[t,3] <- 3-sum(which(model6_par[t,]!=0)<=3)
  store_FN[t,4] <- 3-sum(which(model8_par[t,]!=0)<=3)
  store_FN[t,5] <- 3-sum(which(model0_par[t,]!=0)<=3)
  
  #### Sen ####
  store_SEN[t,1] <- sum(which(model2_par[t,]!=0)<=3)/length(which(beta_set!=0))
  store_SEN[t,2] <- sum(which(model4_par[t,]!=0)<=3)/length(which(beta_set!=0))
  store_SEN[t,3] <- sum(which(model6_par[t,]!=0)<=3)/length(which(beta_set!=0))
  store_SEN[t,4] <- sum(which(model8_par[t,]!=0)<=3)/length(which(beta_set!=0))
  store_SEN[t,5] <- sum(which(model0_par[t,]!=0)<=3)/length(which(beta_set!=0))
  
  #### Spe ####
  store_SPE[t,1] <- sum(which(model2_par[t,]==0)>3)/length(which(beta_set==0))
  store_SPE[t,2] <- sum(which(model4_par[t,]==0)>3)/length(which(beta_set==0))
  store_SPE[t,3] <- sum(which(model6_par[t,]==0)>3)/length(which(beta_set==0))
  store_SPE[t,4] <- sum(which(model8_par[t,]==0)>3)/length(which(beta_set==0))
  store_SPE[t,5] <- sum(which(model0_par[t,]==0)>3)/length(which(beta_set==0))
}
#### change here

# If the parameter is too small, then set it to 0
model0_mean_par <- ifelse(colMeans(model0_par) < 0.1, 0, colMeans(model0_par))

model1_mean_par <- ifelse(colMeans(model1_par) < 0.1, 0, colMeans(model1_par))
model2_mean_par <- ifelse(colMeans(model2_par) < 0.1, 0, colMeans(model2_par))

model3_mean_par <- ifelse(colMeans(model3_par) < 0.1, 0, colMeans(model3_par))
model4_mean_par <- ifelse(colMeans(model4_par) < 0.1, 0, colMeans(model4_par))

model5_mean_par <- ifelse(colMeans(model5_par) < 0.1, 0, colMeans(model5_par))
model6_mean_par <- ifelse(colMeans(model6_par) < 0.1, 0, colMeans(model6_par))

model7_mean_par <- ifelse(colMeans(model7_par) < 0.1, 0, colMeans(model7_par))
model8_mean_par <- ifelse(colMeans(model8_par) < 0.1, 0, colMeans(model8_par))


#### L2 norm ####
L2norm_store[1] <- sum((model2_mean_par-beta_set)^2) # TL correct
L2norm_store[2] <- sum((model4_mean_par-beta_set)^2) # TL naive
L2norm_store[3] <- sum((model6_mean_par-beta_set)^2) # all source TL
L2norm_store[4] <- sum((model8_mean_par-beta_set)^2) # all source Naive
L2norm_store[5] <- sum((model0_mean_par-beta_set)^2) # SIMEXBoost

#### L1 norm ####
L1norm_store[1] <- sum(abs(model2_mean_par-beta_set)) # TL correct
L1norm_store[2] <- sum(abs(model4_mean_par-beta_set)) # TL naive
L1norm_store[3] <- sum(abs(model6_mean_par-beta_set)) # all source TL
L1norm_store[4] <- sum(abs(model8_mean_par-beta_set)) # all source Naive
L1norm_store[5] <- sum(abs(model0_mean_par-beta_set)) # SIMEXBoost


output <- matrix(cbind(L2norm_store, L1norm_store, colMeans(store_S), colMeans(store_FN), colMeans(store_SEN), colMeans(store_SPE)),nrow=5)
colnames(output) <- c("L2norm","L1norm","S","FN","Sen","Spe")
rownames(output) <- c("TL_correct", "TL_naive", "allsource_TL","allsource_Naive", "SIMEXBoost")

settings <- paste("p0=", p0, "_n0=", n0, "_nk=", n[1], "_sigmae=", sigmae_set,".RData", sep="")

ending_time <- Sys.time()

save.image(file=paste("p0=", p0, "_n0=", n0, "_nk=", n[1], "_sigmae=", sigmae_set,".RData", sep=""))

write.csv(output, file=paste("p0=", p0, "_n0=", n0, "_nk=", n[1], "_sigmae=", sigmae_set,".csv", sep=""))

ending_time - starting_time

print("beta_set2 <- c(0,1,1,1,0,0,rep(0, p0-6))")
print("interval-censored")
